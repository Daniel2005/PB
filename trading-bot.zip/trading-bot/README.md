# Paddy Trading Bot 🤖

TradingView → Webhook → Telegram alert system.

---

## Deploy on Railway (free, recommended)

1. Go to https://railway.app and sign up with GitHub
2. Click **"New Project" → "Deploy from GitHub repo"**
3. Upload this folder or paste the code into a new repo
4. Railway auto-detects Node.js and deploys it
5. Go to your project → **Settings → Networking → Generate Domain**
6. Copy your public URL (e.g. `https://paddy-trading-bot.up.railway.app`)

---

## Set up TradingView Alert

1. Open TradingView, go to your chart
2. Click the **Alerts** button (bell icon)
3. Set your condition (price, indicator, etc.)
4. Under **Notifications**, enable **Webhook URL**
5. Paste your URL + `/webhook`:
   ```
   https://your-railway-url.up.railway.app/webhook
   ```
6. In the **Message** box, you can use plain text:
   ```
   BUY NQ at {{close}} — 15m setup
   ```
   Or structured JSON for richer messages:
   ```json
   {"symbol": "NQ1!", "action": "BUY", "price": "{{close}}", "timeframe": "15m", "note": "FVG + BOS confluence"}
   ```

---

## What the Telegram message looks like

**Plain text alert:**
```
⚡ TRADE ALERT

BUY NQ at 21340 — 15m setup

🕐 Sun, 17 May 2026 10:30:00 GMT
```

**JSON alert:**
```
🟢 BUY — NQ1!
💰 Price: 21340
⏱ Timeframe: 15m
📝 FVG + BOS confluence
🕐 Sun, 17 May 2026 10:30:00 GMT
```

---

## Test it manually

Once deployed, send a test alert:
```bash
curl -X POST https://your-url.up.railway.app/webhook \
  -H "Content-Type: application/json" \
  -d '{"symbol":"NQ1!","action":"BUY","price":"21340","timeframe":"15m","note":"Test alert"}'
```

You should get a Telegram message within seconds.
